<?php
	$cn =new mysqli("localhost","root","","sutex");
	$Cust_name = $_REQUEST["Cust_name"];
	$Cust_phno = $_REQUEST["Cust_phno"];
	$Cust_email = $_REQUEST["Cust_email"];
	$Cust_password = $_REQUEST["Cust_password"];

	$query = "insert into Customer_Details(Cust_name,Cust_phno,Cust_email,Cust_password)values('$Cust_name','$Cust_phno','$Cust_email','$Cust_password')";
	$cn->query($query);
	echo "1";
?>
