//
//  validation.swift
//  ProjectDemo
//
//  Created by MAC2 on 27/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class validation: NSObject {

    
    
    func isValidEmail(email:String) -> Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: email)
        return result
    }
    
    func isValidMobile(mobile: String) -> Bool {
        
        //STARTING WITH +91 THEN ONE DIGIT START BETWEEN 7 TO 9 THEN ADD 9 DIGIT BETWEEN 0 TO 9 IT PERMITS +919726174054 / 09726174054
        
        let PHONE_REGEX = "^([+][9][1]|[9][1]|[0]){0,1}([7-9]{1})([0-9]{9})$"
        
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: mobile)
        return result
    }
    
    func isValidPassword(pwd: String) -> Bool {
        
        //Minimum 6 Max 8 characters at least 1 Alphabet, 1 Number and 1 Special Character:
        let PHONE_REGEX = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[$@$!%*#?&])[A-Za-z\\d$@$!%*#?&]{8,}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: pwd)
        return result
    }
    func isValidName(name: String) -> Bool {
        let NAME_REGEX = "^[a-zA-Z]*$"
        
        let nameTest = NSPredicate(format: "SELF MATCHES %@", NAME_REGEX)
        let result =  nameTest.evaluate(with: name)
        return result
    }
    
}
