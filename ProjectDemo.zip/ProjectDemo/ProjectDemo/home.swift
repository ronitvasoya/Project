//
//  home.swift
//  ProjectDemo
//
//  Created by MAC2 on 13/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import EasySocialButton
import  FBSDKLoginKit

class home: UIViewController,FBSDKLoginButtonDelegate {
    @IBOutlet weak var subview: UIView!
    
    //  @IBOutlet weak var btn: UIButton!
    @IBOutlet weak var imgview: UIImageView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBar.isHidden = true
        
        imgview.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
        self.subview.frame = CGRect(x: 0, y: self.view.frame.height - 330 , width: self.view.frame.width, height: 330)
        self.subview.layer.masksToBounds = false;
        self.subview.layer.opacity = 0.8
        self.subview.layer.shadowOffset = CGSize(width: 2, height: 2)
        self.subview.layer.shadowOpacity = 0.8
        
        let loginButton = FBSDKLoginButton(frame: CGRect(x: 35, y: 30, width: 300, height: 40))
        loginButton.readPermissions = ["email"]
        self.subview.addSubview(loginButton)
        loginButton.delegate = self
        
        let diff = UserDefaults.standard
        
        if (diff.value(forKey: "Username") != nil)
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
            
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        
        /*let socialButton = AZSocialButton(frame: CGRect(x: 35, y: 30, width: 300, height: 40))
        
        socialButton.animateInteraction = true
        socialButton.useCornerRadius = true
        socialButton.cornerRadius = 5
        socialButton.highlightOnTouch = false
        socialButton.setImage(UIImage(named: "fb.png"), for: .normal)
        socialButton.setTitle("    Sign in with Facebook", for: [])
        socialButton.setTitleColor(.blue, for: [])
        socialButton.backgroundColor = UIColor.white
        socialButton.titleLabel?.font = UIFont.systemFont(ofSize: 20)
 
        
        
        
        socialButton.onClickAction = { (button) in
            print("do social login stuff")
        }
        */
        let socialButton1 = AZSocialButton(frame: CGRect(x: 35, y: 100, width: 300, height: 40))
        
        socialButton1.animateInteraction = true
        socialButton1.useCornerRadius = true
        socialButton1.cornerRadius = 5
        socialButton1.highlightOnTouch = false
        socialButton1.setImage(UIImage(named: "google.png"), for: .normal)
        socialButton1.setTitle("    Sign in with Google", for: [])
        socialButton1.setTitleColor(.red, for: [])
        socialButton1.backgroundColor = UIColor.red
        socialButton1.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        
        
        socialButton1.onClickAction = { (button) in
            print("do social login stuff")
        }
        
        let socialButton2 = AZSocialButton(frame: CGRect(x: 35, y: 170, width: 300, height: 40))
        
        socialButton2.animateInteraction = true
        socialButton2.useCornerRadius = true
        socialButton2.cornerRadius = 5
        socialButton2.highlightOnTouch = false
        socialButton2.setImage(UIImage(named: "email.png"), for: .normal)
        socialButton2.setTitle("    Sign in with Email", for: [])
        socialButton2.setTitleColor(.black, for: [])
        
        socialButton2.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        
        
        socialButton2.onClickAction = { (button) in
            
            
        }
        let btn = UIButton()
        btn.frame = CGRect(x: 95, y: 225, width: 200, height: 30)
        btn.setTitle("I'll log in later", for: .normal)
        btn.setTitleColor(UIColor.blue, for: .normal)
        btn.addTarget(self, action: #selector(self.test), for: .touchDown)
        
        let label = UILabel(frame: CGRect(x: 60, y: 260, width: 300, height: 20))
        label.text = "By logging in you agree to Food";
        
        let label1 = UILabel(frame: CGRect(x: 75, y: 285, width: 300, height: 20))
        label1.text = "Vector's";
        
        let btn1 = UIButton()
        btn1.frame = CGRect(x: 115, y: 285, width: 200, height: 20)
        btn1.setTitle("Terms & Condition", for: .normal)
        btn1.setTitleColor(UIColor.blue, for: .normal)
        btn1.addTarget(self, action: #selector(self.test1), for: .touchDown)
        
        self.subview.addSubview(label);
        self.subview.addSubview(label1);
        //self.subview.addSubview(socialButton);
        self.subview.addSubview(socialButton1);
        self.subview.addSubview(socialButton2);
        self.subview.addSubview(btn);
        self.subview.addSubview(btn1);
        createnavbar()
        // Do any additional setup after loading the view.
    }
    func test(sender:UIButton) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
    func test1(sender:UIButton) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "t&c")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    func createnavbar()
    {
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "blackcross.png"), for: .normal)
        btn.addTarget(self, action: #selector(close(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }
   @objc func close(_ sender : UIButton)
   {
    
        self.navigationController?.popViewController(animated: true)
        
    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
       print("Login Successfully")
        getFBUserData()
    }
    
    func loginButtonWillLogin(_ loginButton: FBSDKLoginButton!) -> Bool {
        
        return true
        
    }
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        
        print("user Logedout")
        
    }
    func getFBUserData() {
        
        
        
        let graphRequest = FBSDKGraphRequest(graphPath: "me", parameters: ["fields":"id, email, name, picture.width(480).height(480)"])
        graphRequest?.start(completionHandler: { (connection, result, error) in
            if error != nil {
                print("Error",error!.localizedDescription)
            
            }
            else{
                print(result!)
                let field = result! as? [String:Any]
                let diff = UserDefaults.standard
                diff.set(field?["name"] as! String, forKey: "Username")
                let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
                
                self.navigationController?.pushViewController(stb!, animated: true)

                //self.userNameLabel.text = "Hello" + (field?["name"] as! String)
                //print("Hello" + (field?["name"] as! String))
                
                /*if let imageURL = ((field!["picture"] as? [String: Any])?["data"] as? [String: Any])?["url"] as? String {
                    print(imageURL)
                    let url = URL(string: imageURL)
                    let data = NSData(contentsOf: url!)
                    let image = UIImage(data: data! as Data)
                }*/
            }
        })
        
    }
}
