//
//  login.swift
//  ProjectDemo
//
//  Created by TOPS on 10/15/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import TextFieldEffects
import TransitionButton
import SwiftyButton

var obj1 = validation()
var email:Bool = false
var pass:Bool = false

class login: UIViewController,CAAnimationDelegate{

    @IBOutlet weak var login: FlatButton!
    
    @IBOutlet weak var btnshowhide: UIButton!
    @IBOutlet weak var imgview: UIImageView!
    
    @IBOutlet weak var txtemail: UITextField!
    
    @IBOutlet weak var subview: UIView!
    @IBOutlet weak var txtpass: UITextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        imgview.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        subview.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
        self.subview.layer.masksToBounds = false;
        self.subview.layer.opacity = 1
        self.subview.layer.shadowOffset = CGSize(width: 2, height: 2)
        self.subview.layer.shadowOpacity = 1
        
        login.frame = CGRect(x: 20, y: 320 , width: self.view.frame.width-40, height: 50)
        login.color = .red
        login.cornerRadius  = 5
        login.isEnabled = false
         txtpass.isSecureTextEntry = true;
        
        
        let label = UILabel(frame: CGRect(x: 60, y: self.view.frame.height-60, width: 300, height: 20))
        label.text = "By logging in you agree to Food";
        
        let label1 = UILabel(frame: CGRect(x: 75, y: self.view.frame.height-35, width: 300, height: 20))
        label1.text = "Vector's";
        
        let btn1 = UIButton()
        btn1.frame = CGRect(x: 115, y: self.view.frame.height-35, width: 200, height: 20)
        btn1.setTitle("Terms & Condition", for: .normal)
        btn1.setTitleColor(UIColor.blue, for: .normal)
        btn1.addTarget(self, action: #selector(self.test1), for: .touchDown)
        
        let fp = UIButton()
        fp.frame = CGRect(x: 10, y: 420, width: 200, height: 20)
        fp.setTitle("Forgot Password?", for: .normal)
        fp.setTitleColor(UIColor.blue, for: .normal)
        fp.addTarget(self, action: #selector(self.test2), for: .touchDown)
        
        createnavbar()
        self.subview.addSubview(label)
        self.subview.addSubview(label1)
        self.subview.addSubview(btn1)
        self.subview.addSubview(fp)
    }
    
    @IBAction func loginaction(_ sender: UIButton) {
        
        if txtemail.text != "" && txtpass.text != "" {
            
            if obj1.isValidEmail(email: txtemail.text!)
            {
                if obj1.isValidPassword(pwd: txtpass.text!)
                {
                    let url = URL(string: "http://localhost/project/login.php?Cust_email=\(txtemail.text!)&Cust_password=\(txtpass.text!)");
                    let request = URLRequest(url: url!);
                    let session = URLSession.shared;
                    let datatask = session.dataTask(with: request)
                    {
                        (data1, rsp, err) in
                        DispatchQueue.main.async
                            {
                                do
                                {
                                    var jsondata = try JSONSerialization.jsonObject(with: data1!, options: []) as! [Any];
                                    if jsondata.count > 0
                                    {
                                        var dic = jsondata[0] as! [String:String];
                                        let dif = UserDefaults.standard;
                                        dif.set(dic["Cust_name"], forKey: "Username");
                                        let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
                                        self.navigationController?.pushViewController(stb!, animated: true)
                                    }
                                    else
                                    {
                                        let alert = UIAlertController(title: "Alert", message: "Invalid email or password", preferredStyle: .alert);
                                        let ok = UIAlertAction(title: "Ok", style: .default)
                                        {
                                            ACTION in
                                            
                                        }
                                        alert.addAction(ok);
                                        self.present(alert, animated: true, completion: nil);
                                    }
                                    
                                }
                                catch
                                {
                                }
                        }
                    }
                    datatask.resume();
                    
                }else{
                    print("Enter valid password!")
                }
            }else{
                print("Enter valid email!")
            }
            
        }else {
            
            print("Kindly enter fully detail")
        }
        
    }
    @IBAction func btnshowhide(_ sender: UIButton)
    {
        if btnshowhide.titleLabel?.text == "Show"
        {
            txtpass.isSecureTextEntry = false
            btnshowhide.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide.setTitle("Hide", for: .normal)
        }
        else
        {
            txtpass.isSecureTextEntry = true
            btnshowhide.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide.setTitle("Show", for: .normal)
        }
    }
    
    @IBAction func txtemail(_ sender: Any)
    {
        if obj1.isValidEmail(email: txtemail.text!)
        {
            txtemail.rightViewMode = .never
            email = true
            //txtemail.clipsToBounds = true
            //txtemail.layer.borderWidth = 1
            //txtemail.layer.borderColor = UIColor.green.cgColor
        }
        else
        {
            txtemail.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtemail.rightView = imgview
            email = false
            //txtemail.clipsToBounds = true
            //txtemail.layer.borderWidth = 1
            //txtemail.layer.borderColor = UIColor.red.cgColor
        }
        check(email: email, pass: pass)
    }
    @IBAction func txtpass(_ sender: Any)
    {
        if obj1.isValidPassword(pwd: txtpass.text!)
        {
            txtpass.rightViewMode = .never
            //txtpass.clipsToBounds = true
            pass = true
            //txtpass.layer.borderWidth = 1
           //txtpass.layer.borderColor = UIColor.green.cgColor
        }
        else
        {
            txtpass.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtpass.rightView = imgview
            txtpass.clipsToBounds = true
            pass = false
            //txtpass.layer.borderWidth = 1
            //txtpass.layer.borderColor = UIColor.red.cgColor
        }
        check(email: email, pass: pass)
    }
    func check(email:Bool , pass:Bool) {
        
        if email == true && pass == true
        {
            login.isEnabled = true
        }
        else
        {
            login.isEnabled = false
        }
        
    }
    func createnavbar()
    {
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "cross16.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }
    
    func test(_ sender:UIButton) {
    
        navigationController?.popViewController(animated: true)
    }
    
    func test1(sender:UIButton) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "t&c")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    func test2(sender:UIBarButtonItem) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "fp")
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func btnsignup(_ sender: Any) {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "register")
        
        self.navigationController?.pushViewController(stb!, animated: true)

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
