//
//  nearme.swift
//  ProjectDemo
//
//  Created by MAC2 on 02/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import GoogleSignIn

class nearme: UIViewController,UITableViewDataSource,UITableViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource {
    
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var btnfilters: UIButton!
    @IBOutlet weak var tblviewRes: UITableView!
    @IBOutlet weak var OfferCollView: UICollectionView!
    
    var resdetails:[[String:String]] = [[:]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
       btnfilters.backgroundColor = UIColor.lightGray
       btnfilters.layer.cornerRadius = 10
        btnfilters.clipsToBounds = true
        txtSearch.layer.cornerRadius = 10
        txtSearch.clipsToBounds = true
        txtSearch.backgroundColor = UIColor.lightGray
        fatchResData()
    }
    
    func fatchResData() {
        
        let url = URL(string: "http://localhost/project/fatchResDetails.php")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data, rest, err) in

                DispatchQueue.main.async {
                    do{
                    try self.resdetails = JSONSerialization.jsonObject(with: data!, options: []) as! [[String:String]]
                       
                    if self.resdetails.count > 0{
                        self.tblviewRes.reloadData()
                    }
                    }catch{
                        
                    }
            }
        }
        datatask.resume()
        
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resdetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row != 3
        {
            var dic = resdetails[indexPath.row]
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! cell1
            cell.lblReating.layer.cornerRadius = 5
            cell.lblReating.clipsToBounds = true
            cell.lblReating.text = "4.5"
            cell.lblReating.backgroundColor = UIColor.orange
            let str = "http://localhost/project/Restaurant_image/"
            if dic.isEmpty == false
            {
                let finalStr = str.appending(dic["Res_image"]!)
                let url = URL(string: finalStr)
                do{
                    let imgData = try Data.init(contentsOf: url!)
                    cell.imgview.image = UIImage(data: imgData)
                }catch{
                    
                }
            }
            cell.txtviewresname.text = dic["Res_name"]
            if dic["Is_active"] == "1"
            {
                cell.lblLiveTraking.text = "Live Traking"
            }
            else
            {
                
            }
            return cell
        }
        else
        {
            let Colcell = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! cell2
            Colcell.ColviewTranding.reloadData()
            return Colcell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 3
        {
            return 200.0
        }
        else
        {
            return 117.0
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var dic = resdetails[indexPath.row] as! [String:String]
        print(dic["Res_id"])
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView.tag == 0
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colcell1", for: indexPath) as! custcell1
            cell.imgview.image = UIImage(named: "back1.jpg")
            return cell
        }
        else
        {
        //collectionView.register(custcell2, forCellWithReuseIdentifier: "colcell2")
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colcell2", for: indexPath) as! custcell2;
            cell.imgview.image = UIImage(named: "back1.jpg")
        cell.lblResName.text = "Domino's"
        return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(indexPath.row)
    }
}
