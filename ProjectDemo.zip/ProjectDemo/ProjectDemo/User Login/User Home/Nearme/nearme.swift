//
//  nearme.swift
//  ProjectDemo
//
//  Created by MAC2 on 02/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import GoogleSignIn

class nearme: UIViewController,UITableViewDataSource,UITableViewDelegate,UICollectionViewDelegate,UICollectionViewDataSource {
    
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var btnfilters: UIButton!
    @IBOutlet weak var tblviewRes: UITableView!
    @IBOutlet weak var OfferCollView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let diff = UserDefaults.standard
        if (diff.value(forKey: "Username") != nil)
        {
          print(diff.value(forKey: "Username")!)
        }
        
       btnfilters.backgroundColor = UIColor.lightGray
       btnfilters.layer.cornerRadius = 10
        btnfilters.clipsToBounds = true
        txtSearch.layer.cornerRadius = 10
        txtSearch.clipsToBounds = true
        txtSearch.backgroundColor = UIColor.lightGray
        
    }
    

    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row != 3
        {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! cell1
            cell.lblReating.layer.cornerRadius = 5
            cell.lblReating.clipsToBounds = true
            cell.lblReating.text = "4.5"
            cell.imgview.image = UIImage(named: "back1.jpg")
            return cell
        }
        else
        {
            let Colcell = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! cell2
            Colcell.ColviewTranding.reloadData()
            return Colcell
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 3
        {
            return 200.0
        }
        else
        {
            return 117.0
        }
        
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView.tag == 0
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colcell1", for: indexPath) as! custcell1
            cell.imgview.image = UIImage(named: "back1.jpg")
            return cell
        }
        else
        {
        //collectionView.register(custcell2, forCellWithReuseIdentifier: "colcell2")
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colcell2", for: indexPath) as! custcell2;
            cell.imgview.image = UIImage(named: "back1.jpg")
        cell.lblResName.text = "Domino's"
        return cell
        }
    }
}
