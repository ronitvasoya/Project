//
//  custcell1.swift
//  ProjectDemo
//
//  Created by MAC2 on 11/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class custcell1: UICollectionViewCell {
    
    @IBOutlet weak var imgview: UIImageView!
    
}
