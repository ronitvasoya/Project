//
//  profile.swift
//  ProjectDemo
//
//  Created by MAC2 on 09/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
class profile: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        
        let swiftySideMenuVC = self.window?.rootViewController as! SwiftySideMenuViewController
        
        let centerVC = swiftySideMenuVC.storyboard?.instantiateViewControllerWithIdentifier("Center")
        let leftVC = swiftySideMenuVC.storyboard?.instantiateViewControllerWithIdentifier("Left")
        
        swiftySideMenuVC.centerViewController = centerVC
        swiftySideMenuVC.leftViewController = leftVC
        
    }

}
