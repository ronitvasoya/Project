//
//  profile.swift
//  ProjectDemo
//
//  Created by MAC2 on 09/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import GoogleSignIn

class profile: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
          
    }

    @IBAction func logout(_ sender: UIButton) {
        GIDSignIn.sharedInstance().signOut()
        let diff = UserDefaults.standard
        diff.removeObject(forKey: "Username")
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "cdr")
        
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
    
}
