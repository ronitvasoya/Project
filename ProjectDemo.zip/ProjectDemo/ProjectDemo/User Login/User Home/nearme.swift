//
//  nearme.swift
//  ProjectDemo
//
//  Created by MAC2 on 02/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import GoogleSignIn
class nearme: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let diff = UserDefaults.standard
        print(diff.value(forKey: "Username")!)
    }
    

    @IBAction func logout(_ sender: UIButton) {
        GIDSignIn.sharedInstance().signOut()
        let diff = UserDefaults.standard
        diff.removeObject(forKey: "Username")
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
        
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
    

}
