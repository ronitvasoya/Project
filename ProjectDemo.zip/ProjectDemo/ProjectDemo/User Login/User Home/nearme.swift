//
//  nearme.swift
//  ProjectDemo
//
//  Created by MAC2 on 02/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit
import GoogleSignIn

class nearme: UIViewController {
    
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var btnfilters: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let diff = UserDefaults.standard
        if (diff.value(forKey: "Username") != nil)
        {
          print(diff.value(forKey: "Username")!)
        }
        
       btnfilters.backgroundColor = UIColor.lightGray
       btnfilters.layer.cornerRadius = 10
        btnfilters.clipsToBounds = true
        txtSearch.layer.cornerRadius = 10
        txtSearch.clipsToBounds = true
        txtSearch.backgroundColor = UIColor.lightGray
        
    }
    

    @IBAction func logout(_ sender: UIButton) {
        GIDSignIn.sharedInstance().signOut()
        let diff = UserDefaults.standard
        diff.removeObject(forKey: "Username")
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
        
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
    

}
