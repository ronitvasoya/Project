//
//  search.swift
//  ProjectDemo
//
//  Created by MAC2 on 02/01/19.
//  Copyright © 2019 TOPS. All rights reserved.
//

import UIKit

class search: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var txtSearch: UITextField!
     @IBOutlet weak var tblviewRes: UITableView!
    
    var resdetails:[[String:String]] = [[:]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        txtSearch.layer.cornerRadius = 10
        txtSearch.clipsToBounds = true
        txtSearch.backgroundColor = UIColor.lightGray
    }
    
    
    @IBAction func resSearchAction(_ sender: UITextField) {
        fatchResData()
       
    }
    
    func fatchResData() {
        
        let url = URL(string: "http://localhost/project/fatchResDetails.php")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        let datatask = session.dataTask(with: request) { (data, rest, err) in
            
            DispatchQueue.main.async {
                do{
                    try self.resdetails = JSONSerialization.jsonObject(with: data!, options: []) as! [[String:String]]
                    
                    if self.resdetails.count > 0{
                        self.tblviewRes.reloadData()
                    }
                }catch{
                    
                }
            }
        }
        datatask.resume()
        
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return resdetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            var dic = resdetails[indexPath.row]
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! cell
            if dic.isEmpty == false
            {
                
                cell.lblReating.layer.cornerRadius = 5
                cell.lblReating.clipsToBounds = true
                cell.lblReating.text = "4.5"
                let str = "http://localhost/project/Restaurant_image/"
                let finalStr = str.appending(dic["Res_image"]!)
                let url = URL(string: finalStr)
                do{
                    let imgData = try Data.init(contentsOf: url!)
                    cell.imgview.image = UIImage(data: imgData)
                }catch{
                    
                }
                cell.txtviewresname.text = dic["Res_name"]
                if dic["Is_active"] == "1"
                {
                    cell.lblLiveTraking.text = "Live Traking"
                }
                else
                {
                    
                }
            }
            return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 3
        {
            return 200.0
        }
        else
        {
            return 117.0
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var dic = resdetails[indexPath.row] as! [String:String]
        print(dic["Res_id"])
    }
}
