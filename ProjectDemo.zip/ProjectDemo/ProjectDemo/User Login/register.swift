//
//  register.swift
//  ProjectDemo
//
//  Created by TOPS on 10/15/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import TextFieldEffects
import TransitionButton
import SwiftyButton

var obj = validation()
var name:Bool = false
var regemail:Bool = false
var regpass:Bool = false
var phno:Bool = false
class register: UIViewController {

    @IBOutlet weak var register: FlatButton!
    @IBOutlet weak var subview: UIView!
    @IBOutlet weak var txtname: UITextField!
    @IBOutlet weak var txtphno: UITextField!
    @IBOutlet weak var txtemail: UITextField!
    @IBOutlet weak var txtpass: UITextField!
    
    @IBOutlet weak var btnshowhide: UIButton!
    @IBOutlet weak var img: UIImageView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        navigationController?.navigationBar.isHidden = true
        
        img.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        subview.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
        self.subview.layer.masksToBounds = false;
        self.subview.layer.opacity = 1
        self.subview.layer.shadowOffset = CGSize(width: 2, height: 2)
        self.subview.layer.shadowOpacity = 1
        
        register.frame = CGRect(x: 20, y: 450, width: self.view.frame.width-40, height: 50)
        register.color = .red
        register.cornerRadius = 5
        register.isEnabled = false
        createnavbar()
    }

    @IBAction func registeraction(_ sender: Any) {
        
        if txtemail.text != "" && txtphno.text != "" && txtname.text != "" && txtpass.text != "" {
            
            if obj.isValidEmail(email: txtemail.text!) {
                
                if obj.isValidName(name: txtname.text!){
                    
                    if obj.isValidMobile(mobile: txtphno.text!) {
                        
                        if obj.isValidPassword(pwd: txtpass.text!){
                            
                            let url = URL(string: "http://localhost/project/index.php?name=\(txtname.text!)&phno=\(txtphno.text!)&email=\(txtemail.text!)&pass=\(txtpass.text!)");
                            let request = URLRequest(url: url!);
                            let session = URLSession.shared;
                            let datatask = session.dataTask(with: request)
                            {
                                (data1, rsp, err) in
                                let strrep = String(data: data1!, encoding: String.Encoding.utf8);
                                if strrep! == "1"
                                {
                                    
                                    let dif = UserDefaults.standard;
                                    dif.set(self.txtname.text!, forKey: "name");
                                    let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
                                    
                                    self.navigationController?.pushViewController(stb!, animated: true)
                                    
                                }else
                                {
                                    
                                }
                                DispatchQueue.main.async
                                    {
                                        print(strrep!);
                                }
                            }
                            datatask.resume();
                        }else {
                            
                            print("Enter valid password!")
                        }
                    }else {
                        
                        print("Enter valid mobile!")
                    }
                }else {
                    
                    print("Enter valid phone!")
                }
            }else {
                
                print("Enter valid e_mail!")
            }
        }
        else {
            
            print("Kindly enter fully detail")
        }

        
    }
    func check(name:Bool, regemail:Bool , regpass:Bool , phno:Bool) {
        
        if regemail == true && regpass == true && name == true && phno == true
        {
            register.isEnabled = true
        }
        else
        {
            register.isEnabled = false
        }
        
    }
    
    @IBAction func txtname(_ sender: Any)
    {
        if obj.isValidName(name: txtname.text!)
        {
            txtname.rightViewMode = .never
            name = true
            //txtphno.clipsToBounds = true
            //txtphno.layer.borderWidth = 1
            //txtphno.layer.borderColor = UIColor.green.cgColor
        }
        else
        {
            txtname.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtname.rightView = imgview
            name = false
            // txtphno.clipsToBounds = true
            // txtphno.layer.borderWidth = 1
            // txtphno.layer.borderColor = UIColor.red.cgColor
        }
        check(name: name, regemail: regemail, regpass: regpass, phno: phno)
    }
    @IBAction func txtphno(_ sender: Any)
    {
        if obj.isValidMobile(mobile: txtphno.text!)
        {
            txtphno.rightViewMode = .never
            phno = true
            //txtphno.clipsToBounds = true
            //txtphno.layer.borderWidth = 1
            //txtphno.layer.borderColor = UIColor.green.cgColor
        }
        else
        {
            txtphno.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtphno.rightView = imgview
            phno = false
           // txtphno.clipsToBounds = true
           // txtphno.layer.borderWidth = 1
           // txtphno.layer.borderColor = UIColor.red.cgColor
        }
        check(name: name, regemail: regemail, regpass: regpass, phno: phno)
    }
    @IBAction func txtemail(_ sender: Any)
    {
        if obj.isValidEmail(email: txtemail.text!)
        {
            txtemail.rightViewMode = .never
            regemail = true
            //txtemail.clipsToBounds = true
            //txtemail.layer.borderWidth = 1
            //txtemail.layer.borderColor = UIColor.green.cgColor
        }
        else
        {
            txtemail.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtemail.rightView = imgview
            regemail = false
            //txtemail.clipsToBounds = true
            //txtemail.layer.borderWidth = 1
            //txtemail.layer.borderColor = UIColor.red.cgColor
        }
        check(name: name, regemail: regemail, regpass: regpass, phno: phno)
    }
    @IBAction func txtpass(_ sender: Any)
    {
        if obj.isValidPassword(pwd: txtpass.text!)
        {
            txtpass.rightViewMode = .never
            regpass = true
            //txtpass.clipsToBounds = true
            //txtpass.layer.borderWidth = 1
            //txtpass.layer.borderColor = UIColor.green.cgColor
        }
        else
        {
            txtpass.rightViewMode = .whileEditing
            let imgview = UIImageView(image: UIImage(named: "help.png"))
            txtpass.rightView = imgview
            regpass = false
           // txtpass.clipsToBounds = true
           // txtpass.layer.borderWidth = 1
           // txtpass.layer.borderColor = UIColor.red.cgColor
        }
        check(name: name, regemail: regemail, regpass: regpass, phno: phno)
    }
    
    @IBAction func btnshowhide(_ sender: UIButton)
    {
        if btnshowhide.titleLabel?.text == "Show"
        {
            txtpass.isSecureTextEntry = false
            btnshowhide.setImage(UIImage(named: "if_eye_1545742.png"), for: .normal)
            btnshowhide.setTitle("Hide", for: .normal)
        }
        else
        {
            txtpass.isSecureTextEntry = true
            btnshowhide.setImage(UIImage(named: "if_icon-21-eye-hidden_314858.png"), for: .normal)
            btnshowhide.setTitle("Show", for: .normal)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        self.view.endEditing(true)
    }

    func createnavbar()
    {
        let btn = UIButton(type:  .custom)
        btn.setImage(UIImage(named: "cross16.png"), for: .normal)
        btn.addTarget(self, action: #selector(self.test(_:)), for: .touchDown)
        btn.frame = CGRect(x: 15, y: 40, width: 30, height: 30)
        self.view.addSubview(btn)
    }
    
    func test(_ sender:UIButton)
    {
        navigationController?.popViewController(animated: true)
    }
    
   
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
