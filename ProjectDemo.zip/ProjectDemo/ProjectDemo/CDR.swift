//
//  CDR.swift
//  ProjectDemo
//
//  Created by MAC2 on 29/12/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit
import SwiftyButton

class CDR: UIViewController
{

    
    @IBOutlet weak var userbtn: FlatButton!
    
    @IBOutlet weak var resbtn: FlatButton!
    @IBOutlet weak var debtn: FlatButton!
    @IBOutlet weak var subview: UIView!
    @IBOutlet weak var imgview: UIImageView!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        let diff = UserDefaults.standard
        if (diff.value(forKey: "Username") != nil)
        {
            let stb = self.storyboard?.instantiateViewController(withIdentifier: "userhome")
            
            self.navigationController?.pushViewController(stb!, animated: true)
        }
        
        navigationController?.navigationBar.isHidden = true
        tabBarController?.tabBar.isHidden = true
        
       imgview.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
        subview.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        self.subview.layer.masksToBounds = false;
        self.subview.layer.opacity = 0.7
        self.subview.layer.shadowOffset = CGSize(width: 2, height: 2)
        self.subview.layer.shadowOpacity = 0.7
        
        userbtn.frame = CGRect(x: 20, y: 250 , width: self.view.frame.width-40, height: 50)
        userbtn.color = .red
        userbtn.cornerRadius  = 5
        userbtn.addTarget(self, action: #selector(self.userlogin), for: .touchDown)
        
        debtn.frame = CGRect(x: 20, y: 330, width: self.view.frame.width-40, height: 50)
        debtn.cornerRadius  = 5
        debtn.color = .darkGray
        debtn.addTarget(self, action: #selector(self.delogin), for: .touchDown)
        
        resbtn.frame = CGRect(x: 20, y: 410, width: self.view.frame.width-40, height: 50)
        resbtn.cornerRadius  = 5
        resbtn.color = .darkText
        resbtn.addTarget(self, action: #selector(self.reslogin), for: .touchDown)
        
        
        // Do any additional setup after loading the view.
    }
    
    func userlogin(sender : FlatButton)  {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "home")
        
        self.navigationController?.pushViewController(stb!, animated: true)
        
    }
    
    func delogin(sender : FlatButton)  {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "delogin")
        
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    func reslogin(sender : FlatButton)  {
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "reslogin")
        
        self.navigationController?.pushViewController(stb!, animated: true)
    }
    
    
}
