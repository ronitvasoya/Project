-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 17, 2019 at 12:47 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sutex`
--

-- --------------------------------------------------------

--
-- Table structure for table `Category`
--

CREATE TABLE `Category` (
  `Category_id` int(3) NOT NULL,
  `Category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Customer_details`
--

CREATE TABLE `Customer_details` (
  `Cust_id` int(5) NOT NULL,
  `Cust_name` varchar(50) NOT NULL,
  `Cust_phno` bigint(10) NOT NULL,
  `Cust_email` varchar(100) NOT NULL,
  `Cust_password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Customer_details`
--

INSERT INTO `Customer_details` (`Cust_id`, `Cust_name`, `Cust_phno`, `Cust_email`, `Cust_password`) VALUES
(1, 'Ronit', 7575844610, 'vasoyaronit@gmail.com', 'Ronit123@');

-- --------------------------------------------------------

--
-- Table structure for table `DE_Details`
--

CREATE TABLE `DE_Details` (
  `DE_id` int(5) NOT NULL,
  `DE_name` varchar(50) NOT NULL,
  `DE_phno` bigint(10) NOT NULL,
  `DE_email` varchar(100) NOT NULL,
  `DE_image` varchar(50) NOT NULL,
  `Create_date` date NOT NULL,
  `Is_active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Item_Details`
--

CREATE TABLE `Item_Details` (
  `Item_id` bigint(10) NOT NULL,
  `Item_name` varchar(30) NOT NULL,
  `Item_image` varchar(50) NOT NULL,
  `Item_price` int(10) NOT NULL,
  `Is_available` tinyint(1) NOT NULL,
  `Is_veg` tinyint(1) NOT NULL,
  `Category_id` int(3) NOT NULL,
  `Subcategory_id` int(3) NOT NULL,
  `Res_id` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Order_Details`
--

CREATE TABLE `Order_Details` (
  `Order_id` bigint(10) NOT NULL,
  `Order_date` date NOT NULL,
  `Payment_method` varchar(20) NOT NULL,
  `Process_status` varchar(10) NOT NULL,
  `Total_amount` int(5) NOT NULL,
  `Cust_address` varchar(200) NOT NULL,
  `Cust_latitude` varchar(20) NOT NULL,
  `Cust_longitude` varchar(20) NOT NULL,
  `Offer_id` int(3) NOT NULL,
  `Res_id` int(5) NOT NULL,
  `DE_id` int(5) NOT NULL,
  `Cust_id` int(5) NOT NULL,
  `Item_id` varchar(50) NOT NULL,
  `Quantity` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Payment_Details`
--

CREATE TABLE `Payment_Details` (
  `Payment_id` bigint(10) NOT NULL,
  `Cust_id` int(5) NOT NULL,
  `Order_id` bigint(10) NOT NULL,
  `Payment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Restaurant_Details`
--

CREATE TABLE `Restaurant_Details` (
  `Res_id` int(5) NOT NULL,
  `Res_name` varchar(50) NOT NULL,
  `Res_image` varchar(50) NOT NULL,
  `Res_address` varchar(200) NOT NULL,
  `Res_city` varchar(20) NOT NULL,
  `Res_Email` varchar(100) NOT NULL,
  `Res_phno` bigint(10) NOT NULL,
  `Is_active` tinyint(1) NOT NULL,
  `Rating` float NOT NULL,
  `Res_latitude` varchar(20) NOT NULL,
  `Res_longitude` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Restaurant_Details`
--

INSERT INTO `Restaurant_Details` (`Res_id`, `Res_name`, `Res_image`, `Res_address`, `Res_city`, `Res_Email`, `Res_phno`, `Is_active`, `Rating`, `Res_latitude`, `Res_longitude`) VALUES
(1, 'Domino\'s', 'dominos.jpeg', 'Shop no 45 & 46, Ground Floor, Avadh Viceroy,Beside D-Mart, Sarthana Jakat Naka, Subhash Nagar, Nana Varachha, Surat, Gujarat 395006', 'Surat', 'dominospizza@gmail.com', 9865321245, 1, 4.3, '21.2314 N', '72.9036 E');

-- --------------------------------------------------------

--
-- Table structure for table `Sub_Category`
--

CREATE TABLE `Sub_Category` (
  `Subcategory_id` int(3) NOT NULL,
  `Subcategory_name` varchar(50) NOT NULL,
  `Category_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Category`
--
ALTER TABLE `Category`
  ADD PRIMARY KEY (`Category_id`);

--
-- Indexes for table `Customer_details`
--
ALTER TABLE `Customer_details`
  ADD PRIMARY KEY (`Cust_id`),
  ADD UNIQUE KEY `phno` (`Cust_phno`),
  ADD UNIQUE KEY `email` (`Cust_email`);

--
-- Indexes for table `DE_Details`
--
ALTER TABLE `DE_Details`
  ADD PRIMARY KEY (`DE_id`),
  ADD UNIQUE KEY `DE_name` (`DE_name`),
  ADD UNIQUE KEY `DE_email` (`DE_email`);

--
-- Indexes for table `Item_Details`
--
ALTER TABLE `Item_Details`
  ADD PRIMARY KEY (`Item_id`),
  ADD KEY `Category_id` (`Category_id`),
  ADD KEY `item_details_ibfk_1` (`Subcategory_id`),
  ADD KEY `Res_id` (`Res_id`);

--
-- Indexes for table `Order_Details`
--
ALTER TABLE `Order_Details`
  ADD PRIMARY KEY (`Order_id`),
  ADD KEY `Res_id` (`Res_id`),
  ADD KEY `order_details_ibfk_1` (`DE_id`),
  ADD KEY `Cust_id` (`Cust_id`);

--
-- Indexes for table `Payment_Details`
--
ALTER TABLE `Payment_Details`
  ADD PRIMARY KEY (`Payment_id`);

--
-- Indexes for table `Restaurant_Details`
--
ALTER TABLE `Restaurant_Details`
  ADD PRIMARY KEY (`Res_id`),
  ADD UNIQUE KEY `Res_Email` (`Res_Email`),
  ADD UNIQUE KEY `Res_phno` (`Res_phno`);

--
-- Indexes for table `Sub_Category`
--
ALTER TABLE `Sub_Category`
  ADD PRIMARY KEY (`Subcategory_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Category`
--
ALTER TABLE `Category`
  MODIFY `Category_id` int(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Customer_details`
--
ALTER TABLE `Customer_details`
  MODIFY `Cust_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `DE_Details`
--
ALTER TABLE `DE_Details`
  MODIFY `DE_id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Item_Details`
--
ALTER TABLE `Item_Details`
  MODIFY `Item_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Order_Details`
--
ALTER TABLE `Order_Details`
  MODIFY `Order_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Payment_Details`
--
ALTER TABLE `Payment_Details`
  MODIFY `Payment_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Restaurant_Details`
--
ALTER TABLE `Restaurant_Details`
  MODIFY `Res_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Sub_Category`
--
ALTER TABLE `Sub_Category`
  MODIFY `Subcategory_id` int(3) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Item_Details`
--
ALTER TABLE `Item_Details`
  ADD CONSTRAINT `item_details_ibfk_1` FOREIGN KEY (`Res_id`) REFERENCES `Restaurant_Details` (`Res_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
